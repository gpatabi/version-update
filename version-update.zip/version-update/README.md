# TFS-MuleAPIs-CloudHubServices

**Table of Contents**  

- [TFS-MuleAPIs-CloudHubServices](#tfs-muleapis-cloudhubservices)
     - [Mule Version:](#mule-version)
       - [API Summary:](#api-summary)
       - [Core Components:](#core-components)
       - [Property Configurations](#property-configurations)
       - [Usage](#usage)
         -  [1. Version Update](#1-version-update)        
         -  [2. Application Promotion](#2-application-promotion)
       - [Deployment Instructions](#deployment-instructions)
       - [References](#references)



[API Specification](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)

[Project Site](https://github.tfs.toyota.com/pages/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/)


#### Mule Version:

Minimum version to run this application  is 4.3.0

#### API Summary:

CloudHub Helper API supports the following features

- Generate Application status report for all environments.
- Perform Mule version update of applications deployed on CloudHub.
- Promote applications between environments/business groups(orgs).
- Generate Application-Repository mapping information in JSON & YAML format.

| Resource                                   | Method | Description                                                  |
| ------------------------------------------ | ------ | ------------------------------------------------------------ |
| /cloudhub/applications-status              | GET    | Gets high level  statistics of applications deployed on CloudHub in all environments under a specific Business Group. Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details . |
| /repositories                              | GET    | Gets information related to Application- Repository information. ***This is a non trivial operation and might need to be executed prior to PUT /cloudhub/applications or POST /cloudhub/promotion/applications.*** |
| /cloudhub/applications                     | GET    | Gets application details based on input parameters. This resource is useful for scenarios for report generation ( JSON import to Excel) and Version Update . The default response is targeted for report generation. Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details |
| /cloudhub/applications                     | PUT    | Allows to update runtime version of Mule applications deployed on CloudHub. This is a long running task and returns an href link for querying the status of the initiated task. Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details |
| /cloudhub/applications/{process-id}        | GET    | Get the status of task initiated as part of GET /cloudhub/applications .  Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details |
| /cloudhub/promotion/applications           | GET    | Get all eligible applications which can be promoted to the requested environment.  Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details |
| /cloudhub/promotion/applications           | POST   | Allows to promote eligible application from Source to target CloudHub environment. This is a long running task and returns an href link for querying the status of the initiated task. Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details |
| /cloudhub/promotion/applications/{task-id} | GET    | Get the status of task initiated as part of GET /cloudhub/promotion/applications .  Refer [documentation](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/api/api.html)  for more details |



#### Core Components:


- VM
  - Allows to achieve asynchronous capabilities  for long running tasks.
  - Supports persisting messages to disk( Compromise between I/O & Memory) .
  - Another alternate to VM can be Anypoint MQ(AMQ) ( ***Licensing costs are involved***). AMQ has built in circuit breaker capability and useful in making the application resilient during  outbound service outages ( Anypoint Platform & GIT Services unavailability) .


- Aggregator
  - Leverages Object Store .
  - Allows to process data in batches/chunks . All batches/chunks tied to same group . The Group Id utilized is the task Id returned in href links of long running operations.
- GitHub REST API
  - Simple to use and the response is hyper media driven  . Enables discovery of related links which makes the navigation easier
  - Alternative to REST API is Git GraphQL APIs 



#### Property Configurations

- [Core properties](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/core-properties.yaml)

- [Environment Specific properties](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/tfs-properties.yaml)

- [Application/Repository Properties](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/app-repo-properties.yaml)  `Derived from GET /repositories`

- [Application runtime properties](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/promotion/runtime-properties.yaml)  `These properties are utilized during application promotion (POST) . Holds only secure properties which needs to be configured during application promotion. These property values are encrypted`



#### Usage

###### 1. Version Update

------



###### 	  		**Prerequisites**

​		Perform `GET /repositories`  with ***"Accept"*** header set to ***"application/yaml"*** to retrieve the application repository mapping info . [Application/Repository Properties](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/app-repo-properties.yaml) needs to be overridden with the YAML output. There are cases where repository information could not  to determined as shown below.

The repository information is derived from the last updated branch of a repository . If the last updated branch has *"build.properties"* file then the mapping information will be determined.

The below case has master as the last updated branch

```
unable to determine:
  AppNameInBuild: unable to determine
  RepoName: TFS-MuleAPIs-DBConnectivity
  RepoUrl: https://github.tfs.toyota.com/api/v3/repos/EAS-Channel-Access-Services/TFS-MuleAPIs-DBConnectivity
  Branch: master
```

It is advised to exclude these entries from the configuration. Even if retained will not impact the applications behavior.



 **Process**

​	

1. Perform `GET /cloudhub/applications` to retrieve eligible applications for version upgrade.
2. Review the applications returned as part of the response . 

```comments
{
  "eligibleApplications": [
    "adobe-document-services-api-test",
    "adobe-document-services-proxy-test",
    "aemprotectionservices-test",
    "atom-marketdata-test"
  ],
  "excludedApplications": [
    {
      "Application Name": "ipwhitelist-app-test",
      "Reason": "Repository details not available"
    },
    {
      "Application Name": "routeonepniservices-test",
      "Reason": "Repository details not available"
    }
  ]
}

Only applications listed in `"eligibleApplications"`are considered for update . 
```

​			

3. Perform `PUT /cloudhub/applications` to initiate the update process

   ```comments
   {
   
   	"muleVersion": "4.2.2",
   	"environment":"TEST",
   	"businessGroupname": "TFS",
   	"applications": ["authorizedparties-test"],
   	"exclude-higher-versions": false,
   	"update-concurrency": 2
   }
   
   Optional parameters usage:
   
     "applications": ["authorizedparties-test"] .This key will hold application values which needs to be upgraded . This value needs to be obtained from GET /cloudhub/applications (eligibleApplications key value)
   
   
     "exclude-higher-versions" :false . Will force update of applications higher than provided version of "4.2.2" ( 4.3.0 version of applications will be lowered to 4.2.2)
     The default value of "exclude-higher-versions" is set to "true" . The default behaviour is to exclude applications running on higher version
     "update-concurrency" will allow to control the number of applications which needs to be concurrently updated
     if "update-concurrency" is skipped from input then 5 applications are concurrently updated
   ```

4.  `PUT /cloudhub/applications` will result in a `202` response code as shown as below

    

   ```
   {
     "status": "Version Update initiated to  4.1.6",
     "stage": "Update In Progess",
     "task": {
       "href": "/api/cloudhub/applications/b48c0810-ae89-11ea-9464-0050b6923104",
       "id": "b48c0810-ae89-11ea-9464-0050b6923104",
       "type": "GET"
     },
     "data": {
       "includedApplications": [
         "authorizedparties-test"
       ]
     }
   }
   ```

   ​      	

5. Perform `GET /api/cloudhub/applications/${task.id}` to retrieve the status of the version update task .  Sample response as shown below

   ```
   {
     "status": "Application deployment in progress",
     "stage": "Update In Progess",
     "task": {
       "href": "/api/cloudhub/applications/a2a85750-ae8b-11ea-a27d-0050b6923104",
       "id": "a2a85750-ae8b-11ea-a27d-0050b6923104"
     },
     "data": {
       "includedApplications": [
         "authorizedparties-test"
       ],
       "deploymentProgress": {
         "DEPLOYING": [
           "authorizedparties-test"
         ]
       }
     }
   }
   ```

​			

6.  The above step needs to be repeated several times ( run at every 2+ Minutes interval) as the task may take sometime to complete depending on the number of applications supplied. 

7. After a number of invocations `GET /api/cloudhub/applications/${task.id}` will result in a response as shown below . The `status` key with a value of `completed` indicates that the process has been completed.

   ```comments
   {
     "status": "Completed",
     "data": {
       "includedApplications": [
         "authorizedparties-test"
       ],
       "deploymentProgress": {
         "SUCCESS": [
           "authorizedparties-test"
         ]
       },
       "deploymentStatus_1": {
         "authorizedparties-test": "SUCCESS"
       },
       "commiStatus-1": [
         {
           "appName": "authorizedparties-test",
           "deploymentStatus": "SUCCESS",
           "branch": "refs/heads/sys-version-update",
           "pull-url": "https://github.tfs.toyota.com/api/v3/repos/EAS-Channel-Access-Services/TFS-MuleAPIs-authorizedparties-proxy/pulls/11"
         }
       ]
     }
   }
   ```

   

8. The following updates would have been performed when `.status` results in `completed`
   1. Mule version on CloudHub updated with the input version.
   2. Branch named [sys-version-update](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-authorizedparties-proxy/tree/sys-version-update) created.
   3. POM dependencies updated with latest patch version.
   4. `mule-artifact.json` updated with property `minMuleVersion` set to the input version
   5. `Jenkinsfile` updated with `gitURL` set to the correct repository Url and `branches` updated with the value of `deploy.app.branch value specified in build.properties`
   6. Pull request created and reviewers are associated.



###### 2. Application Promotion

------

​	  **Prerequisites**

​		Perform `GET /repositories`  with ***"Accept"*** header set to ***"application/yaml"*** to retrieve the application repository mapping info . [Application/Repository Properties](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/blob/develop/src/main/resources/app-repo-properties.yaml) needs to be overridden with the YAML output. There are cases where repository information could not  to determined as shown below.

If ***"Accept"*** header is not set on `GET /repositories`call , default JSON response will be returned and this representation is useful for reporting purposes. 

Exclude the ***"Accept"*** header if the intent is to generate report ( JSON Import to Excel)

The repository information is derived from the last updated branch of a repository . If the last updated branch has *"build.properties"* file then the mapping information will be determined.

The below case has master as the last updated branch

```
unable to determine:
  AppNameInBuild: unable to determine
  RepoName: TFS-MuleAPIs-DBConnectivity
  RepoUrl: https://github.tfs.toyota.com/api/v3/repos/EAS-Channel-Access-Services/TFS-MuleAPIs-DBConnectivity
  Branch: master
```

It is advised to exclude these entries from the configuration. Even if retained will not impact the applications behavior.

   **Process**

1. Perform `GET /cloudhub/promotion/applications` to retrieve eligible applications which could be promoted to the target environment supplied in the input.

2. Review the applications returned as part of the response . The response looks similar to as shown below

   ```
   {
     "eligibleApps": [
       "____this is just an example____",
       "authorizedparties-app-stage",
       "authorizedparties-stage",
       "oauthprovider-app-stage",
       "loggingframework-app-stage",
       "testing-cicd-eas1-stage",
       "customer-lease-terming-1-stage",
       "customer-lease-terming-sys-app-proxy-stage"
     ],
     "excludedApps": [
       "____this is just an example____",
       "nawcservices-stage",
       "cas-cdar-stage",
       "dealer-callmenow-stage",
       "sfdc-treasury-authentication-api-stage",
       "ods-paymenttransactions-sys-stage",
       "insurance-claim-management-stage",
       "dealersmdmapischedules-sys-stage",
       "kintolink-billing-services-stage",
       "mfin-user-account-services-stage"
     ],
     "availableSourceApps": [
       "____this is just an example____",
       "authorizedparties-stage",
       "oauthprovider-app-stage",
       "loggingframework-app-stage",
       "coupaservices-stage",
       "exp-authorizedparties-stage",
       "retailpaymentextension-stage"
   
     ],
     "availableTargetApps": [
     "____this is just an example____",
       "web-accept-stg",
       "network-connectivity-tools-stg",
       "enterprise-documentlake-services-stg"
   
     ]
   }
   ***
   eligibleApps indicates applications which could be promoted and do not exist in target environment
   excludedApps indicates applications which are missing repository information and cannot be automatically promoted
   availableSourceApps indicates  applications running on source environment
   availableTargetApps indicates applications running on target environment
   ***
   ```

3. Perform `POST  /cloudhub/promotion/applications` to initiate the application promotion task

   ```
   {
     "source": {
       "env": "STAGE",
       "businessGroupname": "TFS"
     },
     "target": {
       "env": "STG",
       "businessGroupname": "TFS"
     },
     "applications": [
       "testing-cicd-eas1-stage"
     ],
     "update-concurrency": 2
   }
   
   ***
   Optional parameters usage
   "applications": [ "testing-cicd-eas1-stage" ]. This value needs to be provided if there is a need to selectively promote applications . If the value is not supplied, All eligible applications listed in GET /cloudhub/promotion/applications will be considered for promotion.
   "update-concurrency": 2. This value controls the number of concurrent promotions to make . If the value is skipped then the default value of 5 is considered
   
   ***
   ```

   

4. `POST  /cloudhub/promotion/applications` will result in `202` accepted response as shown below

   ```
   {
     "status": "Version Update initiated to  4.1.6",
     "stage": "Update In Progess",
     "task": {
       "href": "/api/cloudhub/applications/b48c0810-ae89-11ea-9464-0050b6923104",
       "id": "b48c0810-ae89-11ea-9464-0050b6923104",
       "type": "GET"
     },
     "data": {
       "includedApplications": [
         "authorizedparties-test"
       ]
     }
   }
   ```

5. Perform `GET /cloudhub/promotion/applications/{$.task.id}`to get the status of application promotion task . This needs to be repeated until the `status` changes to `Completed` . Ideal to run every 2+ minutes.

6. After a number of invocations of `GET /cloudhub/promotion/applications/{$.task.id}` will result in a response as shown below . The `status` key with a value of `completed` indicates that the process has been completed.

   ```
   {
     "status": "Completed",
     "stage": "complete",
     "data": {
       "configuration": {
         "loggingframework-app-stg": "No further configuration required",
         "testing-cicd-eas1-stg": "No further configuration required"
       },
       "promoted-1": [
         "loggingframework-app-stg",
         "testing-cicd-eas1-stg"
       ],
       "deploymentStatus-1": {
         "loggingframework-app-stg": "STARTED",
         "testing-cicd-eas1-stg": "STARTED"
       },
       "commitStatus-1": {
         "loggingframework-app-stg": {
           "appStatus": "STARTED",
           "branch": "sys-application-promotion",
           "pullRequest": "https://github.tfs.toyota.com/api/v3/repos/EAS-Channel-Access-Services/TFS-MuleAPIs-LoggingFramework/pulls/13"
         },
         "testing-cicd-eas1-stg": {
           "appStatus": "STARTED",
           "branch": "sys-application-promotion",
           "pullRequest": "https://github.tfs.toyota.com/api/v3/repos/EAS-Channel-Access-Services/TFS-MuleAPIs-TEST_CICD/pulls/7"
         }
       }
     }
   }
   ```

   

7. The following updates would have been performed when `.status` results in `completed`
   1. Application gets promoted to the requested target environment
   2. `mule-artifact.json` updated with property `secureProperties` set to key names which needs to be safely hidden on cloudhub.
   3. Branch named [sys-application-promotion](https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-TEST_CICD/tree/sys-application-promotion) created.
   4. Pull request created and reviewers are associated.

#### Deployment Instructions

Standalone

```
pass system property  -DsecureKey=<<Pass Key used for encryption>>
```

CloudHub

```
provide secureKey runtime property for application.
```





#### References

1) [RAML to HTML documentation generator](https://github.com/raml2html/raml2html/blob/master/README.md)

2) [![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/d9c102b5d337f942aaea)

3) [Postman Collection Import](https://github.tfs.toyota.com/raw/EAS-Channel-Access-Services/TFS-MuleAPIs-CloudHubServices/develop/src/main/resources/postman-collection/CloudHub%20Helper%20API.postman_collection.json)